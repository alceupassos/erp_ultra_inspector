# Objetivo
- Usar OpenAI como Oráculo para gerar insights, narrativas e ações nas páginas de Comercial, Operações, Financeiro, SGQ, Compliance e CS.
- Reaproveitar a infraestrutura já existente (lib/ai.ts) e expandir para um endpoint /api/oracle/ask com prompt contextual por área.

# Variáveis de Ambiente
- OPENAI_API_KEY (já configurada)
- ORACLE_ENABLED=true|false (liga/desliga)
- ORACLE_MODEL=gpt-4.1|gpt-4o-mini (ou o modelo desejado)
- ORACLE_TIMEOUT=20000 (ms)

# Backend
- Criar /api/oracle/ask
  - Entrada: { area, filters, kpis, sampleRows, metadata, mode, question? }
  - Montar prompt: bloco geral + bloco por área + filtros + KPIs + amostras (mascarando PII)
  - Chamar OpenAI (Responses API, JSON) com timeout e retries
  - Saída: { insights: [...], narrative, actions: [...], confidence }
- PII & Segurança
  - Mascarar CPF/CNPJ/email/telefone em sampleRows
  - Tamanho máximo payload (ex.: 25k chars) e top N linhas (ex.: 50)
  - Rate limit por usuário/rota; logs sem dados sensíveis
- Cache curto (ex.: 5 min) por chave de contexto (area+filters)

# UI Componentes
- OraclePanel (reutilizável)
  - Abas: Insights, Narrativa, Ações
  - Botões: Perguntar, Gerar narrativa, Próximas ações
  - Exportar markdown; copiar; estado de carregando/erro
- Inline Ask
  - Em Explorer/Metadados: “Explicar estes dados” (usa colunas visíveis + filtros)
  - Nos dashboards: botão flutuante com prompt contextual

# Integração por Área (prompts)
- Comercial: tendência, mix, margens, top/bottom, riscos e oportunidades
- Operações: OTIF, lead time, rupturas, backlog, priorização
- Financeiro: aging, inadimplência, fluxo caixa, margem; planos
- SGQ: NCs, auditorias, CAPA; eficácia e próximos passos
- Compliance: encrypt/TDE score, features perigosas, auditoria; hardening
- CS: health/adoção, NPS, churn risk; playbooks (onboarding/expansão/recuperação)

# Integração nas Páginas
- Comercial & SGQ (Fase 1): adicionar OraclePanel aos dashboards
- Explorer: botão “Explicar estes dados”; Metadados: “Descrever objeto/Sugerir KPIs”
- Demais áreas (Fase 2): Operações/Financeiro; Fase 3: Compliance/CS

# Observabilidade
- Métricas de uso: por área, modo (insights/narrative/actions), tempo resposta
- Logs mínimos (sem dados sensíveis); surface de erros amigável

# Roadmap
- Fase 1: endpoint /api/oracle/ask + OraclePanel em Comercial/SGQ + inline Ask em Explorer
- Fase 2: Operações/Financeiro + inline Ask em Metadados
- Fase 3: Compliance/CS + playbooks com CTAs
- Fase 4: caching/rate-limit/telemetria e refinamento de prompts

# Validação
- Testes com filtros e amostras reais; checar precisão e utilidade das ações
- Ajustar prompts e payload conforme feedback

Confirmo avançar com Fase 1 imediatamente usando sua OPENAI_API_KEY, adicionando ORACLE_MODEL/ORACLE_TIMEOUT/ORACLE_ENABLED no .env.local.