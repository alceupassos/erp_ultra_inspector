# Visão Geral
- Adicionar login com Google e menu inicial com 3 opções: "Conexão ULTRA", "Testar login" e "Sistema CEPALAB".
- Ler credenciais do arquivo Markdown "conexão-sql-sgc-md" para conectar ao SGQ (CEPALAB), listar todas as views/tabelas e construir uma UI de exploração organizada.
- Você está rodando localmente, então podemos aceitar senha no fluxo de desenvolvimento sem mascarar na geração do .md (mantendo boas práticas na UI).

# Autenticação Google
## Tecnologias
- Auth.js (NextAuth v5) com Provider Google; sessão via JWT.
## Entregas
- Botão "Entrar com Google" na landing; estado de sessão no Topbar (nome/avatar/logout).
- Middleware protegendo: `/ultra-conexao`, `/testar-login`, `/cepalab`.
- Variáveis: `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `AUTH_SECRET`.

# Menu e Navegação
- Landing pós-login com 3 cards (glow/neuromórfico):
  - "Conexão ULTRA": reusa tela atual de análise.
  - "Testar login": testar credenciais SQL (porta, SELECT 1).
  - "Sistema CEPALAB": ingestão SGQ e exploração de dados.

# Ingestão de Credenciais (conexão-sql-sgc-md)
## Parser MD
- Suportar chaves: Servidor, Porta, Database, Usuário, Senha.
- Normalizar para: `server`, `port`, `database`, `user`, `password` e colocar em memória de sessão.
- Como está local, a senha pode ser mantida no md gerado e exibida na UI (com aviso de uso apenas local).
## Fallback
- Se o md não existir/estiver incompleto, permitir upload ou edição manual na UI.

# Sistema CEPALAB (SGQ)
## APIs
- `GET /api/sgq/list`: schemas, tabelas, views, colunas, contagens.
- `POST /api/sgq/query`: paginação, ordenação, filtros básicos.
## UI
- 3 seções:
  1) Panorama SGQ: KPIs (total tabelas/views, top 10), gráficos.
  2) Explorar: lista por schema (busca), tabela paginada ao abrir item, export CSV.
  3) Metadados: colunas, tipos, índices/chaves.
- Tagging: view/tabela/sensível/grande.

# Testar Login
- Página com formulário (Servidor/Porta/Usuário/Senha/Database).
- Botões: "Testar porta" (TCP ping), "SELECT 1" (teste de query).
- Card "Sugestões para resolução" destacando: credenciais/firewall/TLS/TDE.

# Segurança (ajustada ao local)
- UI mostra senha apenas por estar em ambiente local; logs não persistem credenciais.
- Sanitização de consultas: whitelist de tabelas/views; sem SQL arbitrário.
- Rate limit básico nas APIs para evitar travamentos.

# Integração com o existente
- Reaproveitar `ConnectionForm`, `ping-sql`, dashboards e logs.
- Manter tema laranja/glow/neuromórfico.

# Passos Técnicos
1) Adicionar Auth.js com Google e middleware.
2) Criar landing com 3 cards (links para rotas).
3) Implementar parser do md (upload/leitura local) e estado de sessão com credenciais.
4) Implementar APIs sgq/list e sgq/query.
5) Construir página `/cepalab` (Panorama/Explorar/Metadados).
6) Construir `/testar-login` (ping e SELECT 1).
7) Polimento: logs, sugestão dinâmica, export CSV.

# Variáveis de Ambiente (dev)
- `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `AUTH_SECRET`.
- Opcional: `MSSQL_*` como fallback se o md não for fornecido.

# Validação
- Fluxo: login Google → landing → CEPALAB → ingestão md → listar/abrir objetos → export; testes de porta/SELECT 1 funcionam.

Deseja que eu avance com essa implementação agora?