# Entendimento da CEPALAB (resumo)
- Empresa brasileira com mais de 20 anos, foco em saúde diagnóstica e produtos: diabetes care, autotestes, materiais laboratoriais.
- Atuação multicanal: varejo (redes de drogarias), hospitalar e governo (licitações). Parcerias relevantes (ABRAFAD etc.).
- Operação com SGQ (qualidade), logística e presença nacional; relação com governo indica contratos e compliance.

# Implicações para o Sistema
- Organizar o front end por Linhas de Produto (Diabetes, Autotestes, Materiais, Laboratorial) e por Canais (Varejo/Hospitalar/Governo).
- KPIs específicos por linha e canal: volume, receita, distribuição, margem, devoluções, rupturas.
- Camada SGQ integrada: NCs por linha/canal, auditorias, CAPA; rastreabilidade de lotes e fornecedores.
- Market Access: mapas de presença (redes), performance por estado/região, contratos públicos e prazos.

# Replanejamento por Áreas
## 1) Linhas de Produto
- Painéis por Linha: demanda (sell-out/sell-in), devoluções, margem, disponibilidade, lotes/qualidade.
- Explorer por linha: catálogo, lotes, estoque, pedidos, eventos de qualidade.
- Ações: ajuste de mix, campanhas por rede, requalificação de fornecedores.

## 2) Canais (Varejo/Hospitalar/Governo)
- Painéis por Canal: KPIs de receita, margem, ruptura, lead time, cobertura geográfica.
- Governo: contratos, entregas, prazos e conformidade (licitações). Alertas de SLA e auditorias.
- Varejo: distribuição por redes, sell-out, promoções; Hospitalar: consumo e estoque crítico.

## 3) SGQ Integrado
- NCs por linha/canal, tempo de resolução; auditorias e CAPA; eficácia de ação.
- Rastreio de lotes, fornecedores críticos e impacto em canais.
- Ações: planos de ação, requalificação, treinamento.

## 4) Market Access / Presença Nacional
- Cobertura geográfica: heatmaps por estado/rede; penetração e potencial.
- Contratos e licitações: cronograma, indicadores de atendimento, alertas.

## 5) Customer Success
- Health/adoção por cliente (rede/hospital/município); NPS; uso de dashboards.
- Playbooks: onboarding por canal; expansão por linha; recuperação de baixo desempenho.
- Adoção por equipe interna (comercial, logística, qualidade).

# Estrutura Técnica
- Landing por Linhas/Canais; filtro global (período, estado, rede).
- Dashboards com drill-down → explorers (views/tabelas) → metadados.
- Agregações adequadas a cada canal; export CSV; favoritos e consultas salvas.
- Segurança: TOTP diário, TLS/TDE, PII mascarada.

# Próximos Passos
- Mapear views/tabelas atuais para Linhas e Canais (taxonomia).
- Definir KPIs críticos por Linha/Canal e SGQ; suas consultas base.
- Implementar painéis iniciais (ex.: Autotestes/Varejo + SGQ) e explorers com filtros.
- Integrar Market Access (presença nacional) com mapas e rankings por rede/UF.

Deseja que eu avance com a implementação seguindo este replanejamento focado em Linhas de Produto e Canais da CEPALAB, integrando SGQ e Market Access?