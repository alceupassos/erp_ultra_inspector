## **Opção Mínima (Só Documentação)**
- `docs/CEPALAB_ANALISE_COMPLETA_2025.md` (documento principal para Cursor 2.0)
- `docs/CEPALAB_Sistema_Completo_Documentacao.md` (guia detalhado de módulos, dashboards e queries)
- `docs/CEPALAB_Plano_Completo.md` (plano resumido de implementação)
- `docs/conexao-sql-sgc.md` (modelo de credenciais; recomendo mover valores sensíveis para `.env`)

## **UI e Dashboards (Opcional)**
- Componentes de páginas e dashboards:
  - `app/cepalab/page.tsx` (lista de objetos e prévia TOP 100)
  - `components/PerformanceDashboard.tsx`
  - `components/SecurityDashboard.tsx`
  - `components/AIReport.tsx`
  - `components/AnalysisSummary.tsx`
- Componentes utilitários e UI:
  - `components/ui/{badge.tsx, button.tsx, card.tsx, input.tsx, label.tsx, textarea.tsx, utils.ts}`
  - `components/charts/{KpiBarChart.tsx, RowsByTableChart.tsx, TablesByCategoryChart.tsx, VulnerabilityRadarChart.tsx}`
  - `components/layout/{Sidebar.tsx, Topbar.tsx}`
  - `components/auth/GlobalLogout.tsx`

## **APIs (Opcional, Next.js App Router)**
- `app/api/sgq/list/route.ts` (lista tabelas/views)
- `app/api/sgq/query/route.ts` (executa consultas; requer credenciais em body)
- `app/api/analyze/route.ts` (orquestra análises)
- `app/api/ping-sql/route.ts` (saúde da conexão)
- `app/api/oracle/ask/route.ts` (integração com OpenAI)
- Opcional de auth:
  - `app/api/auth/[...nextauth]/route.ts`
  - `app/auth/error/page.tsx`

## **Libs e Tipos (Reutilização de Lógica)**
- `lib/sqlInspector.ts` (inventário de tabelas/colunas/PK/FK)
- `lib/securityInspector.ts` (inspeção de dados sensíveis e config) — usa padrões como em `lib/securityInspector.ts:66`
- `lib/performanceInspector.ts` (índices, fragmentação, queries) — DMVs em `lib/performanceInspector.ts:73`
- `lib/types.ts` (tipos como `TableInfo`, `AnalysisResult`)
- `lib/metrics.ts`, `lib/classifier.ts`, `lib/dataDiscovery.ts` (auxiliares)
- `lib/utils.ts`
- Opcional: `lib/ai.ts`, `lib/rag/cepalab.tsx` (IA e RAG)

## **Variáveis de Ambiente (no projeto CEPALAB)**
- `MSSQL_SERVER`, `MSSQL_PORT`, `MSSQL_DATABASE`, `MSSQL_USER`, `MSSQL_PASSWORD`
- `NEXTAUTH_URL`, `NEXTAUTH_SECRET` (se usar auth)
- `OPENAI_API_KEY` (se usar Oráculo/IA)
- Observação: o endpoint `POST /api/sgq/query` exige os campos `server`, `port`, `user`, `password`, `database` e `sql` no body (`app/api/sgq/query/route.ts:10`).

## **Dependências a instalar**
- Recharts: `recharts`
- Ícones: `lucide-react`
- Animações: `framer-motion`
- UI: `clsx`, `tailwind-merge`
- MSSQL: `mssql`
- (Opcional) Auth: `next-auth`
- (Opcional) OpenAI: `openai`

## **Estrutura Sugerida no CEPALAB**
- `docs/` (copiar arquivos .md)
- `components/` (copiar UI e charts necessários)
- `lib/` (copiar lógica de inspeção/metrics/types)
- `app/api/` (copiar rotas que vai usar)
- Ajustar imports relativos após copiar (por exemplo, caminhos `@/components/ui/...`).

## **Boas Práticas**
- Manter credenciais apenas em `.env` e não em arquivos .md
- Não executar operações de escrita no banco; apenas leitura
- Usar paginação e limites (`TOP`) em consultas para grandes tabelas
- Sanitizar parâmetros de filtros antes de enviar ao SQL

Confirma se quer que eu prepare um pacote compactado contendo exatamente esses arquivos, já com substituição de caminhos de import para o projeto CEPALAB.