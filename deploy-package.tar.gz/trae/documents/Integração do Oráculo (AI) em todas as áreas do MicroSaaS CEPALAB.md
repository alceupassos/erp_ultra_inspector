# Objetivo
- Integrar um “Oráculo” (AI) em todas as páginas/áreas para gerar insights, narrativas, recomendações e planos de ação com base nas views/tabelas e filtros ativos.
- Usar variáveis no `.env.local` para configuração da API do Oráculo.

# Variáveis de Ambiente
- `ORACLE_API_URL` (endpoint HTTP da API)
- `ORACLE_API_KEY` (chave da API)
- `ORACLE_MODEL` (modelo: ex. `oraculo-v1`)
- `ORACLE_TIMEOUT` (ms: ex. `20000`)
- `ORACLE_ENABLED` (`true|false`)

# Endpoints Backend
## 1) `POST /api/oracle/ask`
- Entrada: `{ area, context, filters, question?, mode }`
  - `area`: comercial|operacoes|financeiro|sgq|compliance|cs
  - `context`: resumo de métricas, amostra de linhas, metadados (schemas/objetos)
  - `filters`: período, BU, canal, estado
  - `mode`: `insights|narrative|actions|explain`
  - `question?`: pergunta livre do usuário
- Saída: `{ insights: [...], narrative: string, actions: [...], confidence: number }`
- Segurança: rate limit, timeouts; logs sem dados sensíveis.

# Templates de Prompt (por Área)
- Comercial: tendência, mix, margens, top/bottom clientes/produtos, riscos e oportunidades.
- Operações: OTIF, lead time, rupturas, backlog; priorizações e reabastecimento.
- Financeiro: aging, inadimplência, fluxo de caixa, margem; planos de renegociação.
- SGQ: NCs, auditorias, CAPA; eficácia e próximos passos.
- Compliance: encrypt/TDE score, features perigosas, auditoria; hardening.
- CS: health/adoção, NPS, churn risk; playbooks de onboarding/expansão/recuperação.

# Componentes UI
## 1) `OraclePanel`
- Abas: “Insights”, “Narrativa”, “Ações”.
- Botões: “Perguntar ao Oráculo”, “Gerar narrativa”, “Próximas ações”.
- Estados: carregando/erro; exportar markdown; copiar.

## 2) “Ask Oráculo” Inline
- Em cada dashboard: botão flutuante com prompt contextual (filtros ativos)
- Em cada tabela: “Explicar estes dados” (pega colunas/linhas visíveis)

# Integração por Página
- Landing: oráculo de recomendação de onde começar (com base em uso e dados recentes).
- Comercial/Operações/Financeiro/SGQ/Compliance/CS: cada dashboard recebe `OraclePanel` com contexto da página + filtros.
- Explorer: botão “Explicar” e “Gerar insights” sobre o objeto e amostras TOP N.
- Metadados: “Descrever o objeto” e “Sugerir KPIs” a partir das colunas/índices/chaves.

# Pipeline de Contexto
- Coletar: filtros globais, KPIs do dashboard, top N linhas (limite ~50), metadados do objeto.
- Normalizar: remover PII sensível ou mascarar; compactar números (ex.: 201.5k).
- Montar payload: `area + context + filters + mode` e enviar ao `/api/oracle/ask`.

# Segurança & Privacidade
- Não enviar senhas; mascarar CPF/CNPJ/email/telefone.
- Sanitizar payload; limite de caracteres.
- Rate limit por usuário/rota; cache curto de respostas (5–10 min) por contexto.

# Observabilidade
- Log de chamadas (área, duração, sucesso/erro); sem dados sensíveis.
- Métricas: uso por área, modos mais usados (insights/narratives/actions), tempo resposta.

# UX Detalhado
- Oráculo fixo no topo direito do dashboard; abre painel lateral.
- Resultados com tags (ganho estimado, esforço, risco) e CTAs (abrir relatório, aplicar filtro, exportar plano).
- Narrativas com seções (Resumo, Oportunidades, Riscos, Próximos Passos).

# Roadmap de Implementação
## Fase 1
- Backend `/api/oracle/ask` + `OraclePanel` (componentes base).
- Integração em Comercial e SGQ (piloto) com prompts prontos.
## Fase 2
- Operações e Financeiro; “Ask Oráculo” inline em explorer/metadados.
## Fase 3
- Compliance e CS; playbooks com CTAs.
## Fase 4
- Caching, rate limit, observabilidade; refinamento de prompts por uso real.

# Validação
- Teste em cada área com filtros realistas.
- Avaliação de precisão/tempo/ação; ajuste de prompt e payload.

Quando você colocar a API no `.env.local` (ORACLE_API_URL/KEY), avançamos com Fase 1 e piloto em Comercial e SGQ.