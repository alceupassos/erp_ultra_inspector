# Conexão SQL Server — SGQ

Servidor: 104.234.224.238
Porta: 1445
Database: sgc
Usuário: ops
Senha: Suporte2022=Mais

MSSQL_SERVER=104.234.224.238
MSSQL_PORT=1445
MSSQL_DATABASE=sgc
MSSQL_USER=ops
MSSQL_PASSWORD=Suporte2022=Mais
